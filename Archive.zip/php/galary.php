<?php
//build html
	$html = <<<HTML
	<div>
		<span> <img src="resources/pic/538562_412442158834174_925128859_n.jpg" width="420" height="315"></span>
		<span> <img src="resources/pic/577781_3997110226645_1091874106_n.jpg" width="560" height="315"></span>
		<span> <img src="resources/pic/IMG_3683.JPG" width="420" height="315"></span>

	</div>
	<div>
	<iframe width="420" height="315" src="//www.youtube.com/embed/B35V11qUmt4" frameborder="0" allowfullscreen></iframe>
	<iframe width="560" height="315" src="//www.youtube.com/embed/-ybmzGu-5q4" frameborder="0" allowfullscreen></iframe>
	<iframe width="420" height="315" src="//www.youtube.com/embed/0zN1hzJOb_M" frameborder="0" allowfullscreen></iframe>
	</div>
	
HTML;

	echo($html);
?>
