<?php
//build html
	$html = <<<HTML
<div class="widget_iframe" style="display:inline-block;width:100%;height:550px;margin:0;padding:0;border:0;"><iframe class="widget_iframe" src="http://www.reverbnation.com/widget_code/html_widget/artist_2885009?widget_id=52&pwc[design]=default&pwc[background_color]=%23333333&pwc[layout]=detailed&pwc[show_map]=0%2C1&pwc[size]=fit" width="100%" height="100%" frameborder="0" scrolling="no"></iframe><div class="footer_branding" style="margin-top:-5px;font-size:10px;font-family:Arial;"><center><a href="http://www.reverbnation.com/band-promotion/fanreach?utm_campaign=a_features_fanreach&utm_medium=widget&utm_source=HTML5_Show_Schedule&utm_content=widgetfooter_Get Band email for free at ReverbNation.com" target="_blank" style="text-decoration:none;color:#444;">Get Band email for free at ReverbNation.com</a></center></div></div>
HTML;

	echo($html);
?>
