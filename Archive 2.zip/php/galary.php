<?php
//build html
	$html = <<<HTML
		<div>
	<iframe width="420" height="315" src="//www.youtube.com/embed/B35V11qUmt4" frameborder="0" allowfullscreen></iframe>
	<iframe width="560" height="315" src="//www.youtube.com/embed/-ybmzGu-5q4" frameborder="0" allowfullscreen></iframe>
	<iframe width="420" height="315" src="//www.youtube.com/embed/0zN1hzJOb_M" frameborder="0" allowfullscreen></iframe>
	</div>
		<div>
			<ul class="hoverbox">
			<li>
				<a href="#"><img src="resources/pic/1.jpg" alt="description" />
				<img src="resources/pic/1.jpg" alt="description" class="preview" /></a>
			</li>
			<li>
				<a href="#"><img src="resources/pic/2.jpg" alt="description" />
				<img src="resources/pic/2.jpg" alt="description" class="preview" /></a>
			</li>
			<li>
				<a href="#"><img src="resources/pic/3.jpg" alt="description" />
				<img src="resources/pic/3.jpg" alt="description" class="preview" /></a>
			</li>
			<li>
				<a href="#"><img src="resources/pic/4.jpg" alt="description" />
				<img src="resources/pic/4.jpg" alt="description" class="preview" /></a>
			</li>
			<li>
				<a href="#"><img src="resources/pic/5.jpg" alt="description" />
				<img src="resources/pic/5.jpg" alt="description" class="preview" /></a>
			</li>
			<li>
				<a href="#"><img src="resources/pic/6.jpg" alt="description" />
				<img src="resources/pic/6.jpg" alt="description" class="preview" /></a>
			</li>
			<li>
				<a href="#"><img src="resources/pic/7.jpg" alt="description" />
				<img src="resources/pic/7.jpg" alt="description" class="preview" /></a>
			</li>
			<li>
				<a href="#"><img src="resources/pic/8.jpg" alt="description" />
				<img src="resources/pic/8.jpg" alt="description" class="preview" /></a>
			</li>
			<li>
				<a href="#"><img src="resources/pic/9.jpg" alt="description" />
				<img src="resources/pic/9.jpg" alt="description" class="preview" /></a>
			</li>
			<li>
				<a href="#"><img src="resources/pic/10.jpg" alt="description" />
				<img src="resources/pic/10.jpg" alt="description" class="preview" /></a>
			</li>
			<li>
				<a href="#"><img src="resources/pic/11.jpg" alt="description" />
				<img src="resources/pic/11.jpg" alt="description" class="preview" /></a>
			</li>
			<li>
				<a href="#"><img src="resources/pic/12.jpg" alt="description" />
				<img src="resources/pic/12.jpg" alt="description" class="preview" /></a>
			</li>
			<li>
				<a href="#"><img src="resources/pic/13.jpg" alt="description" />
				<img src="resources/pic/13.jpg" alt="description" class="preview" /></a>
			</li>
			<li>
				<a href="#"><img src="resources/pic/14.jpg" alt="description" />
				<img src="resources/pic/14.jpg" alt="description" class="preview" /></a>
			</li>
			<li>
				<a href="#"><img src="resources/pic/15.jpg" alt="description" />
				<img src="resources/pic/15.jpg" alt="description" class="preview" /></a>
			</li>
			<li>
				<a href="#"><img src="resources/pic/16.jpg" alt="description" />
				<img src="resources/pic/16.jpg" alt="description" class="preview" /></a>
			</li>
			<li>
				<a href="#"><img src="resources/pic/17.jpg" alt="description" />
				<img src="resources/pic/17.jpg" alt="description" class="preview" /></a>
			</li>
			<li>
				<a href="#"><img src="resources/pic/18.jpg" alt="description" />
				<img src="resources/pic/18.jpg" alt="description" class="preview" /></a>
			</li>
			</ul>

		<div>
HTML;

	echo($html);
?>
